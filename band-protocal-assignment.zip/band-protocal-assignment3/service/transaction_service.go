package service

import (
	"github.com/bandprotocol/domain"
	"github.com/gofiber/fiber/v2"
)

type TransactionService struct {
	transactionDomain domain.Transaction
}

func NewTransactionService(transactionDomain domain.Transaction) *TransactionService {
	return &TransactionService{
		transactionDomain: transactionDomain,
	}
}

func (ts *TransactionService) CreateTransaction(c *fiber.Ctx) error {
	var req domain.BroadcastRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "Invalid request"})
	}

	txHash, err := ts.transactionDomain.CreateTransaction(req.Symbol, req.Price, req.Timestamp)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(fiber.Map{
		"message":     "Transaction broadcasted",
		"transaction": txHash,
	})
}

func (ts *TransactionService) MonitorTransactionStatus(c *fiber.Ctx) error {
	txHash := c.Params("txHash")

	status, err := ts.transactionDomain.MonitorTransactionStatus(txHash)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(fiber.Map{
		"txHash": txHash,
		"status": status,
	})
}
