package domain

type BroadcastRequest struct {
	Symbol    string `json:"symbol"`
	Price     uint64 `json:"price"`
	Timestamp uint64 `json:"timestamp"`
}

type BroadcastResponse struct {
	TxHash string `json:"tx_hash"`
}

// Response structure for transaction status
type StatusResponse struct {
	TxStatus string `json:"tx_status"`
}

type Transaction interface {
	CreateTransaction(symbol string, price uint64, timestamp uint64) (string, error) 
	MonitorTransactionStatus(txHash string) (string, error)         
}
