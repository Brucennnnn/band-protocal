package route

import (
	"github.com/bandprotocol/config"
	"github.com/bandprotocol/service"
	"github.com/gofiber/fiber/v2"
)

type Route struct {
	cfg     *config.Config
	service *Service
}

func NewRoute(cfg *config.Config, service *Service) *Route {
	return &Route{
		cfg:     cfg,
		service: service,
	}
}

type Service struct {
	TransactionService *service.TransactionService
}

func NewService(transactionService *service.TransactionService) *Service {
	return &Service{
		TransactionService: transactionService,
	}
}

func (r *Route) RegisterRouter(f fiber.Router) {
	transaction := f.Group("/transactions")

	transaction.Post("/", r.service.TransactionService.CreateTransaction)

	transaction.Get("/:txHash", r.service.TransactionService.MonitorTransactionStatus)
}
