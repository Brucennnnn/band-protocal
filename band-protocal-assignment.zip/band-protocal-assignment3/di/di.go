package di

import (
	"github.com/bandprotocol/client"
	"github.com/bandprotocol/config"
	
	"github.com/bandprotocol/route"
	"github.com/bandprotocol/service"
)

func DI(cfg *config.Config) *route.Service {

	// Initialize client
	transactionClient := client.NewTransactionClient(cfg.ServerURL)

	// Initialize service
	transactionService := service.NewTransactionService(transactionClient)
	service := route.NewService(transactionService)

	return service
}
