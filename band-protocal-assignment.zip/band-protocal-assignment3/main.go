package main

import (
	"log/slog"
	"os"

	"github.com/bandprotocol/config"
	"github.com/bandprotocol/di"
	"github.com/bandprotocol/route"
	"github.com/gofiber/fiber/v2"
	fiberSwagger "github.com/swaggo/fiber-swagger"
)

func main() {
	defer func() {
		if r := recover(); r != nil {
			slog.Error("recover from panic!",
				slog.Any("err", r),
			)
		}
	}()

	cfg := config.Load()
	app := fiber.New()
	handler := di.DI(cfg)
	router := route.NewRoute(cfg, handler)
	router.RegisterRouter(app)



	app.Get("/swagger/*", fiberSwagger.WrapHandler)
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080" // Default port if not specified
	}

	host := os.Getenv("HOST")
	if host == "" {
		host = "0.0.0.0" // Default host if not specified
	}
	

	err := app.Listen(host + ":" + port)
	if err != nil {
		panic(err)
	}
}
