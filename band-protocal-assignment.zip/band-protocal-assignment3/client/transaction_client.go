package client

import (
	"fmt"
	"time"

	"github.com/bandprotocol/domain"
	"github.com/go-resty/resty/v2"
)

type TransactionClient struct {
	baseURL string
}

func NewTransactionClient(baseURL string) *TransactionClient {
	return &TransactionClient{baseURL: baseURL}
}

func (ts *TransactionClient) CreateTransaction(symbol string, price uint64, timestamp uint64) (string, error) {
	client := resty.New()

	payload := &domain.BroadcastRequest{
		Symbol:    symbol,
		Price:     price,
		Timestamp: timestamp,
	}

	var result domain.BroadcastResponse
	resp, err := client.R().
		SetBody(payload).SetResult(&result).
		Post("https://mock-node-wgqbnxruha-as.a.run.app/broadcast")

	if err != nil {
		return "", err
	}

	if resp.StatusCode() != 200 {
		return "", fmt.Errorf("error broadcasting transaction: %s", resp.Status())
	}

	return result.TxHash, nil
}

func (ts *TransactionClient) MonitorTransactionStatus(txHash string) (string, error) {
	client := resty.New()
	var statusResponse domain.StatusResponse

	for {
		resp, err := client.R().
			SetResult(&statusResponse).
			Get(fmt.Sprintf("https://mock-node-wgqbnxruha-as.a.run.app/check/%s", txHash))

		if err != nil {
			return "", err
		}

		if resp.StatusCode() != 200 {
			return "", fmt.Errorf("error checking transaction status: %s", resp.Status())
		}

		status := statusResponse.TxStatus
		if status == "CONFIRMED" || status == "FAILED" {
			break
		}

		time.Sleep(5 * time.Second)
	}

	return statusResponse.TxStatus, nil
}
