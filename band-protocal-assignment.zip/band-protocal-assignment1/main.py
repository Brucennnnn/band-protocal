from bossbabyrevenge import boss_baby_revenge

def main():
    events= input("Please enter the events: ")
    print(boss_baby_revenge(events))


if __name__ == "__main__":
    main()